sap.ui.define(["sap/fe/core/AppComponent"],function(n){"use strict";return n.extend("ibm.vendorinfo.sapathonui.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map